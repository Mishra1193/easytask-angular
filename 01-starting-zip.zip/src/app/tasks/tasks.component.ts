import { Component, Input } from '@angular/core';
import { TaskComponent } from './task/task.component';
import { CommonModule } from '@angular/common';
import { Task } from './task/task.model';

@Component({
  selector: 'app-tasks',
  standalone: true,
  imports: [TaskComponent, CommonModule],
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.css'], // ✅ fixed typo here
})
export class TasksComponent {
  @Input({ required: true }) name!: string;
  @Input({ required: true }) userId!: string;

  tasks = [
    {
      id: 't1',
      title: 'Master Angular',
      summary: 'Learn all the basic and advanced features of Angular & how to apply them.',
      dueDate: '2025, 11, 31',
      userId: 'u1',
    },
    {
      id: 't2',
      title: 'Learn TypeScript',
      summary: 'Understand types, interfaces, and advanced TypeScript features.',
      dueDate: '2025, 10, 30',
      userId: 'u2',
    },
    {
      id: 't3',
      title: 'Explore RxJS',
      summary: 'Dive into reactive programming and observables.',
      dueDate: '2025, 9, 15',
      userId: 'u3',
    },
  ];

  get selectedUserTasks() {
    return this.tasks.filter(task => task.userId === this.userId);
  }

  onCompleteTask(id: string) {
    console.log('[Parent] Removing task:', id); // ✅ Debug
    this.tasks = this.tasks.filter(task => task.id !== id);
  }

  trackById(index: number, task: Task): string {
    return task.id;
  }
}
