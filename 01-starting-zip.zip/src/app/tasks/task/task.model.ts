export interface Task {
  id: string;
  title: string;
  summary: string;
  dueDate: string;
  userId: string;
}
