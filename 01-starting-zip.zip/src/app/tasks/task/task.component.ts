import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Task } from './task.model'; // Adjust the import path as necessary
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-task',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './task.component.html',
  styleUrls : ['./task.component.css']
})
export class TaskComponent {
    @Input({ required: true }) task!: Task;
    // @output() decorator for emitting events to pass data to parent components once clicked on complete button
    @Output() complete = new EventEmitter<string>();
  // Method to handle task completion
  // This method will emit the task ID when the "Mark as Done" button is clicked
  onComplete() {
    this.complete.emit(this.task.id);
    console.log('[Child] Complete clicked for task:', this.task.id);
  }
}
