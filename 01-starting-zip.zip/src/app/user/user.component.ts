import { Component, Input, output } from '@angular/core';
import { User } from './user.model'; // Adjust the import path as necessary


@Component({
  selector: 'app-user',
  standalone: true,
  templateUrl: './user.component.html',
  styleUrl: './user.component.css',
})
export class UserComponent {
  // 👇 Step 2: Accept the entire User object as a required input
  @Input({ required: true }) user!: User;
  @Input({required : true}) isSelected!: boolean;

  // 👇 Step 3: Use signal-based output (better modern approach)
  select = output<string>();

  // 👇 Step 4: Return full avatar path using the `user` object
  get imagePath() {
    return `assets/users/${this.user.avatar}`;
  }

  // 👇 Step 5: Emit user ID when the user is selected
  // it goes to the parent component since this is a child component
  // parent component can listen to this event 
  onSelectUser() {
    this.select.emit(this.user.id);
  }
}
